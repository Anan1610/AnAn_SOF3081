<script setup>
import Bai4 from './components/Bai4.vue'
</script>

<template>
  <Bai4 />
</template>
